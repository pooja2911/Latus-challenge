<?php

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://accounts.spotify.com/api/token');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data['grant_type'] = 'refresh_token';
$data['refresh_token'] = 'AQC5sKWsnUdEk1XGc7lPry4YKntp8H63Fv7wM_vpcnqprKIyvXW0Tli9nAawl35_eF2ex6fZySw0h7Dia038kCCPZ-5IlIeDXn7BzhvecPE1wU7iM4iyTSAOYVFraaq1JeM';
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
$headers = array();
$headers[] = 'Authorization: Basic ' . base64_encode('44ca9e1f6e504fb0a7cd5ec6c8882878:b24fce5bb0b04076939dfb926de78a1d');
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
echo $result;

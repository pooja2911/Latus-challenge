<?php

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://accounts.spotify.com/api/token');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data['grant_type'] = 'authorization_code';
$data['code'] = 'AQBx8oJDfY4OuDs3GwR6G5yc6UPkf0ojeBN59X4RqeocxSAmOoQ0XDzdTemD1jwjOYKtbsP7HqpKOE32HsYxpNa9ITfCyJd80-RWcGDSH47nEI4yKCg6-k3lM56xQ4roS84dDQ5QEPxMpwnRZ_OOm_QJpOF458Re5oKhkk3-otfF_VpSZqOx06RKSvaEND4x';
$data['redirect_uri'] = 'http://localhost/challenge/demo/callback.php';
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
$headers = array();
$headers[] = 'Authorization: Basic ' . base64_encode('44ca9e1f6e504fb0a7cd5ec6c8882878:b24fce5bb0b04076939dfb926de78a1d');
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
echo $result;

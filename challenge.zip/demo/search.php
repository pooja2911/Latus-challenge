<?php

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://api.spotify.com/v1/search?type=album&include_external=audio&q=arijit');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

$headers = array();
$headers[] = 'Authorization: Bearer BQAYXgafBWI_72rKp2xS0wNhd3_zh0ycioN3yIZXPp0GFJKXvujLggNUBTFby7bm0EpC5vQX-OPHpVP-hPRddPfxaoAAfGmiBdDuP4UTOgphxHSJkPJpvI9XTY_KZhMFxfa0wjFElKWyXZg4KO4GNCG68NLyA9-lUGq-Zg';
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
echo $result;

<?php

echo $_GET['code']."<br>";
//echo $_GET['state']."<br>";
